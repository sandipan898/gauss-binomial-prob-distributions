from setuptools import setup

setup(name='gauss-binomial-distributions-pkg',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['gauss-binomial-distributions-pkg'],
      author='Sandipan Das',
      author_email='sandipan.das898@gmail.com',
      zip_safe=False)
