from setuptools import setup

setup(name='gauss_binomial_prob_distributions',
      version='1.0',
      description='Gaussian and Binomial distributions',
      packages=['gauss_binomial_prob_distributions'],
      author='Sandipan Das',
      author_email='sandipan.das898@gmail.com',
      zip_safe=False)
