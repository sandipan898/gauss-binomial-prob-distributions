from setuptools import setup

setup(name='prob-distributions',
      version='0.1',
      description='Gaussian distributions',
      packages=['prob-distributions'],
      zip_safe=False)
